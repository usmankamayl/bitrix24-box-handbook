<?php
/**
 * Файл для регистрации агента очистки логов
 *
 * Запустите этот файл один раз для добавления агента в систему
 */

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");

use Bitrix\Main\Agent;
use Bitrix\Main\Loader;

// Подключаем файл с агентом
require_once __DIR__ . '/agent.php';

// Проверяем, не добавлен ли уже агент
$existingAgent = Agent::getList([
    'filter' => [
        'NAME' => '\\MyCompany\\Agents\\CleanOldLogsAgent::execute();'
    ]
])->fetch();

if ($existingAgent) {
    echo "Агент уже зарегистрирован (ID: {$existingAgent['ID']})<br>";
} else {
    // Добавляем агент через D7
    $agentId = Agent::add([
        'NAME' => '\\MyCompany\\Agents\\CleanOldLogsAgent::execute();',
        'MODULE_ID' => '',
        'ACTIVE' => 'Y',
        'AGENT_INTERVAL' => 86400,           // Раз в сутки (24 * 3600)
        'IS_PERIOD' => 'Y',                  // Периодический агент
        'NEXT_EXEC' => new \Bitrix\Main\Type\DateTime(), // Первый запуск сразу
    ]);

    if ($agentId) {
        echo "Агент успешно добавлен (ID: {$agentId})<br>";
        echo "Интервал запуска: раз в сутки<br>";
        echo "Следующий запуск: в ближайшее время<br>";
    } else {
        echo "Ошибка при добавлении агента<br>";
    }
}

echo "<br><a href='/bitrix/admin/agent_list.php'>Перейти к списку агентов</a>";

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php");
