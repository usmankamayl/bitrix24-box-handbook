<?php
/**
 * Агент для очистки старых логов
 *
 * Задача: Удалять файлы логов старше 30 дней из папки /upload/logs/
 *
 * Этот агент демонстрирует:
 * - Работу с файловой системой
 * - Обработку ошибок в агентах
 * - Логирование результатов работы
 * - Безопасное удаление файлов
 */

namespace MyCompany\Agents;

use Bitrix\Main\Diag\Debug;
use Bitrix\Main\IO\Directory;
use Bitrix\Main\IO\File;

class CleanOldLogsAgent
{
    /**
     * Количество дней, после которых лог считается устаревшим
     */
    const DAYS_TO_KEEP = 30;

    /**
     * Путь к папке с логами (относительно DOCUMENT_ROOT)
     */
    const LOGS_DIR = '/upload/logs/';

    /**
     * Основной метод агента
     *
     * @return string - имя функции для следующего запуска
     */
    public static function execute()
    {
        try {
            // Получаем абсолютный путь к папке с логами
            $logsPath = $_SERVER['DOCUMENT_ROOT'] . self::LOGS_DIR;

            // Проверяем, существует ли директория
            if (!Directory::isDirectoryExists($logsPath)) {
                self::log("Директория логов не найдена: {$logsPath}");
                return self::getAgentName();
            }

            // Получаем список файлов
            $directory = new Directory($logsPath);
            $files = $directory->getChildren();

            $deletedCount = 0;
            $totalSize = 0;
            $now = time();
            $daysInSeconds = self::DAYS_TO_KEEP * 86400; // 86400 секунд в сутках

            // Обрабатываем каждый файл
            foreach ($files as $fileObject) {
                // Пропускаем директории
                if ($fileObject instanceof Directory) {
                    continue;
                }

                /** @var File $fileObject */
                $filePath = $fileObject->getPath();

                // Проверяем возраст файла
                $fileModTime = $fileObject->getModificationTime();
                $fileAge = $now - $fileModTime;

                // Если файл старше заданного срока - удаляем
                if ($fileAge > $daysInSeconds) {
                    $fileSize = $fileObject->getSize();

                    // Удаляем файл
                    if ($fileObject->delete()) {
                        $deletedCount++;
                        $totalSize += $fileSize;

                        self::log("Удален файл: " . $fileObject->getName() .
                                 " (возраст: " . round($fileAge / 86400) . " дней, " .
                                 "размер: " . self::formatBytes($fileSize) . ")");
                    }
                }
            }

            // Логируем итоги
            if ($deletedCount > 0) {
                self::log("Очистка завершена. Удалено файлов: {$deletedCount}, " .
                         "освобождено места: " . self::formatBytes($totalSize));
            } else {
                self::log("Устаревших логов не найдено");
            }

        } catch (\Exception $e) {
            // Обрабатываем ошибки
            self::logError($e->getMessage());

            // Отправляем уведомление администратору
            self::notifyAdmin($e->getMessage());
        }

        // Возвращаем имя функции для следующего запуска
        return self::getAgentName();
    }

    /**
     * Получить имя агента для регистрации
     *
     * @return string
     */
    private static function getAgentName()
    {
        return __METHOD__ . "();";
    }

    /**
     * Логирование информационных сообщений
     *
     * @param string $message
     */
    private static function log($message)
    {
        Debug::writeToFile(
            $message,
            date("Y-m-d H:i:s"),
            "/logs/clean_logs_agent.log"
        );

        // Также записываем в системный журнал событий
        \CEventLog::Add([
            "SEVERITY" => "INFO",
            "AUDIT_TYPE_ID" => "CLEAN_LOGS_AGENT",
            "DESCRIPTION" => $message,
        ]);
    }

    /**
     * Логирование ошибок
     *
     * @param string $message
     */
    private static function logError($message)
    {
        Debug::writeToFile(
            $message,
            date("Y-m-d H:i:s") . " ERROR",
            "/logs/clean_logs_agent_errors.log"
        );

        \CEventLog::Add([
            "SEVERITY" => "ERROR",
            "AUDIT_TYPE_ID" => "CLEAN_LOGS_AGENT",
            "DESCRIPTION" => $message,
        ]);
    }

    /**
     * Отправить уведомление администратору об ошибке
     *
     * @param string $errorMessage
     */
    private static function notifyAdmin($errorMessage)
    {
        \CEvent::Send(
            "AGENT_ERROR",
            SITE_ID,
            [
                "AGENT_NAME" => "CleanOldLogsAgent",
                "ERROR_MESSAGE" => $errorMessage,
                "DATE_TIME" => date("d.m.Y H:i:s"),
            ]
        );
    }

    /**
     * Форматирование размера в человекочитаемый вид
     *
     * @param int $bytes
     * @param int $precision
     * @return string
     */
    private static function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];

        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }

        return round($bytes, $precision) . ' ' . $units[$i];
    }
}
