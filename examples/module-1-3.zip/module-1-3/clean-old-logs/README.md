# Задача 1: Агент очистки старых логов

## 📝 Описание задачи

Создать агент, который будет автоматически удалять файлы логов старше 30 дней из папки `/upload/logs/`.

## 🎯 Что демонстрирует этот пример

- Работа с файловой системой через D7 API
- Обработка ошибок в агентах (try-catch)
- Логирование результатов работы агента
- Отправка уведомлений администратору при ошибках
- Безопасное удаление файлов
- Форматирование данных (размер файлов)

## 📂 Файлы

- `agent.php` - класс агента с логикой очистки
- `install.php` - скрипт для регистрации агента в системе
- `README.md` - описание и инструкции (этот файл)

## 🚀 Установка

### Вариант 1: Через скрипт установки

1. Скопируйте папку `clean-old-logs` в ваш проект
2. Откройте в браузере: `http://ваш-сайт.ru/путь/к/clean-old-logs/install.php`
3. Агент будет автоматически зарегистрирован

### Вариант 2: Добавление вручную через код

```php
use Bitrix\Main\Agent;
use Bitrix\Main\Type\DateTime;

require_once __DIR__ . '/agent.php';

Agent::add([
    'NAME' => '\\MyCompany\\Agents\\CleanOldLogsAgent::execute();',
    'ACTIVE' => 'Y',
    'AGENT_INTERVAL' => 86400,  // Раз в сутки
    'IS_PERIOD' => 'Y',
    'NEXT_EXEC' => new DateTime(),
]);
```

### Вариант 3: Через административную панель

1. Перейдите: **Настройки → Инструменты → Агенты**
2. Нажмите **"Добавить агент"**
3. Заполните поля:
   - **Название функции:** `\MyCompany\Agents\CleanOldLogsAgent::execute();`
   - **Интервал запуска:** `86400` (24 часа)
   - **Активность:** Да
   - **Периодический:** Да

## ⚙️ Настройка для работы через cron

Для точного выполнения по расписанию настройте cron:

**1. Создайте файл `/bitrix/php_interface/cron_agents.php`:**

```php
<?php
$_SERVER["DOCUMENT_ROOT"] = "/path/to/your/site";
$DOCUMENT_ROOT = $_SERVER["DOCUMENT_ROOT"];

define("NO_KEEP_STATISTIC", true);
define("NOT_CHECK_PERMISSIONS", true);
define('BX_CRONTAB', true);

require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

CAgent::CheckAgents();

@define("BX_CRONTAB_SUPPORT", true);
```

**2. Добавьте задачу в crontab:**

```bash
# Запуск каждую ночь в 2:00
0 2 * * * /usr/bin/php /path/to/site/bitrix/php_interface/cron_agents.php
```

**3. Обновите агент для работы через cron:**

```php
Agent::update($agentId, [
    'IS_CRON' => 'Y'  // Агент будет выполняться только через cron
]);
```

## 🔧 Настройка параметров

В файле `agent.php` можно изменить константы:

```php
// Количество дней хранения логов
const DAYS_TO_KEEP = 30;

// Путь к папке с логами
const LOGS_DIR = '/upload/logs/';
```

## 📊 Логирование

Агент записывает информацию в два места:

### 1. Файлы логов
- `/bitrix/logs/clean_logs_agent.log` - успешные операции
- `/bitrix/logs/clean_logs_agent_errors.log` - ошибки

### 2. Журнал событий Bitrix
**Настройки → Журнал событий**

Тип события: `CLEAN_LOGS_AGENT`

## ✅ Проверка работы

### Проверить статус агента:
```php
use Bitrix\Main\Agent;

$agent = Agent::getList([
    'filter' => ['NAME' => '%CleanOldLogsAgent%']
])->fetch();

echo "Следующий запуск: " . $agent['NEXT_EXEC'];
echo "Последний запуск: " . $agent['LAST_EXEC'];
```

### Запустить агент вручную:
```php
\MyCompany\Agents\CleanOldLogsAgent::execute();
```

### Проверить логи:
Откройте файл `/bitrix/logs/clean_logs_agent.log`

## 🔍 Как это работает

1. **Агент запускается** по расписанию (раз в сутки)
2. **Проверяет папку** `/upload/logs/`
3. **Сканирует файлы** и проверяет дату модификации
4. **Удаляет файлы** старше 30 дней
5. **Логирует результаты** (количество удаленных файлов, освобожденное место)
6. **При ошибке** отправляет уведомление администратору

## 💡 Ключевые моменты кода

### Безопасное удаление
```php
if ($fileAge > $daysInSeconds) {
    if ($fileObject->delete()) {
        $deletedCount++;
    }
}
```

### Обработка ошибок
```php
try {
    // Основная логика
} catch (\Exception $e) {
    self::logError($e->getMessage());
    self::notifyAdmin($e->getMessage());
}
return self::getAgentName(); // Всегда возвращаем имя функции
```

### Работа с файлами через D7
```php
use Bitrix\Main\IO\Directory;
use Bitrix\Main\IO\File;

$directory = new Directory($logsPath);
$files = $directory->getChildren();
```

## 🎓 Что можно доработать

1. **Добавить параметры:** передавать путь и срок хранения через аргументы агента
2. **Архивирование:** вместо удаления сжимать старые логи в zip
3. **Уведомления:** отправлять отчет администратору после каждого запуска
4. **Фильтрация:** удалять только определенные типы файлов (*.log, *.txt)
5. **Статистика:** собирать статистику по освобожденному месту

## 📚 Связанные темы

- Работа с файлами в D7: `Bitrix\Main\IO\Directory`, `Bitrix\Main\IO\File`
- Логирование: `Bitrix\Main\Diag\Debug`, `CEventLog`
- Почтовые события: `CEvent::Send()`

## 🐛 Решение проблем

### Агент не запускается
- Проверьте права доступа к папке с логами
- Убедитесь, что агент активен в админке
- Проверьте логи ошибок

### Файлы не удаляются
- Проверьте права на запись в папку
- Убедитесь, что путь к папке указан правильно
- Проверьте, существует ли папка

### Ошибка "Call to undefined method"
- Убедитесь, что подключен модуль main
- Проверьте namespace класса агента
